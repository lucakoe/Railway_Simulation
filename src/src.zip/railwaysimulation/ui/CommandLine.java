package railwaysimulation.ui;

public class CommandLine {
}
