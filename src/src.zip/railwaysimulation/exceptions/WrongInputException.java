package railwaysimulation.exceptions;

public class WrongInputException extends Exception{
    public WrongInputException(String message){
        super(message);
    }
}
